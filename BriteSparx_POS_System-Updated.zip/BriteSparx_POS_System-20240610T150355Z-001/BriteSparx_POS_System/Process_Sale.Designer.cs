﻿
namespace BriteSparx_POS_System
{
    partial class Process_Sale_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtTotal = new System.Windows.Forms.Button();
            this.dgvProductSearch = new System.Windows.Forms.DataGridView();
            this.productIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.availableStockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pRODUCTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.g17Wst2024DataSet = new BriteSparx_POS_System.G17Wst2024DataSet();
            this.dgvCart = new System.Windows.Forms.DataGridView();
            this.pRODUCTcartBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtProductDescrip = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.pRODUCTBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.g17Wst2024DataSet1 = new BriteSparx_POS_System.G17Wst2024DataSet();
            this.pRODUCTTableAdapter = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.PRODUCTTableAdapter();
            this.productTableAdapter1 = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.PRODUCTTableAdapter();
            this.pRODUCTcartTableAdapter = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.PRODUCTcartTableAdapter();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxCollectionMethod = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxPaymentMethod = new System.Windows.Forms.ComboBox();
            this.sALEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.btnFinaliseSale = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtCustomerSearch = new System.Windows.Forms.TextBox();
            this.dgvCustIDSearch = new System.Windows.Forms.DataGridView();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerSurnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cUSTOMERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnCustomer = new System.Windows.Forms.Button();
            this.comboBoxEmployeeID = new System.Windows.Forms.ComboBox();
            this.eMPLOYEEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.eMPLOYEETableAdapter = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.EMPLOYEETableAdapter();
            this.cUSTOMERTableAdapter = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.CUSTOMERTableAdapter();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.saleTableAdapter1 = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.SALETableAdapter();
            this.salE_ITEMSTableAdapter1 = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.SALE_ITEMSTableAdapter();
            this.productIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salePriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnReturn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g17Wst2024DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTcartBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g17Wst2024DataSet1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sALEBindingSource)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustIDSearch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eMPLOYEEBindingSource)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(123, 661);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 28);
            this.txtTotal.TabIndex = 0;
            this.txtTotal.UseVisualStyleBackColor = true;
            this.txtTotal.Click += new System.EventHandler(this.txtTotal_Click);
            // 
            // dgvProductSearch
            // 
            this.dgvProductSearch.AutoGenerateColumns = false;
            this.dgvProductSearch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProductSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductSearch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.availableStockDataGridViewTextBoxColumn,
            this.salePriceDataGridViewTextBoxColumn});
            this.dgvProductSearch.DataSource = this.pRODUCTBindingSource;
            this.dgvProductSearch.Location = new System.Drawing.Point(49, 156);
            this.dgvProductSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvProductSearch.Name = "dgvProductSearch";
            this.dgvProductSearch.Size = new System.Drawing.Size(793, 185);
            this.dgvProductSearch.TabIndex = 1;
            this.dgvProductSearch.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProductSearch_CellContentClick);
            this.dgvProductSearch.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvProductSearch_RowHeaderMouseClick);
            // 
            // productIDDataGridViewTextBoxColumn
            // 
            this.productIDDataGridViewTextBoxColumn.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.Name = "productIDDataGridViewTextBoxColumn";
            this.productIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            // 
            // availableStockDataGridViewTextBoxColumn
            // 
            this.availableStockDataGridViewTextBoxColumn.DataPropertyName = "available_Stock";
            this.availableStockDataGridViewTextBoxColumn.HeaderText = "available_Stock";
            this.availableStockDataGridViewTextBoxColumn.Name = "availableStockDataGridViewTextBoxColumn";
            // 
            // salePriceDataGridViewTextBoxColumn
            // 
            this.salePriceDataGridViewTextBoxColumn.DataPropertyName = "Sale_Price";
            this.salePriceDataGridViewTextBoxColumn.HeaderText = "Sale_Price";
            this.salePriceDataGridViewTextBoxColumn.Name = "salePriceDataGridViewTextBoxColumn";
            // 
            // pRODUCTBindingSource
            // 
            this.pRODUCTBindingSource.DataMember = "PRODUCT";
            this.pRODUCTBindingSource.DataSource = this.g17Wst2024DataSet;
            // 
            // g17Wst2024DataSet
            // 
            this.g17Wst2024DataSet.DataSetName = "G17Wst2024DataSet";
            this.g17Wst2024DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dgvCart
            // 
            this.dgvCart.AutoGenerateColumns = false;
            this.dgvCart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCart.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIDDataGridViewTextBoxColumn1,
            this.nameDataGridViewTextBoxColumn1,
            this.descriptionDataGridViewTextBoxColumn1,
            this.salePriceDataGridViewTextBoxColumn1,
            this.Quantity,
            this.dataGridViewTextBoxColumn1});
            this.dgvCart.DataSource = this.pRODUCTcartBindingSource;
            this.dgvCart.Location = new System.Drawing.Point(23, 23);
            this.dgvCart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvCart.Name = "dgvCart";
            this.dgvCart.Size = new System.Drawing.Size(885, 185);
            this.dgvCart.TabIndex = 2;
            this.dgvCart.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.dgvCart.CellValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCart_CellValidated);
            this.dgvCart.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCart_CellValueChanged);
            this.dgvCart.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.dgvCart_RowStateChanged);
            // 
            // pRODUCTcartBindingSource
            // 
            this.pRODUCTcartBindingSource.DataMember = "PRODUCTcart";
            this.pRODUCTcartBindingSource.DataSource = this.g17Wst2024DataSet;
            // 
            // txtProductDescrip
            // 
            this.txtProductDescrip.Location = new System.Drawing.Point(151, 37);
            this.txtProductDescrip.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtProductDescrip.Name = "txtProductDescrip";
            this.txtProductDescrip.Size = new System.Drawing.Size(132, 23);
            this.txtProductDescrip.TabIndex = 3;
            this.txtProductDescrip.TextChanged += new System.EventHandler(this.txtProductDescrip_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 41);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Product Search:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnClear);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtProductDescrip);
            this.groupBox1.Controls.Add(this.dgvProductSearch);
            this.groupBox1.Location = new System.Drawing.Point(776, 79);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(1071, 358);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Products";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(309, 31);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(104, 34);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Location = new System.Drawing.Point(35, 250);
            this.btnTotal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(100, 28);
            this.btnTotal.TabIndex = 6;
            this.btnTotal.Text = "Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(164, 250);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 28);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // pRODUCTBindingSource1
            // 
            this.pRODUCTBindingSource1.DataMember = "PRODUCT";
            this.pRODUCTBindingSource1.DataSource = this.g17Wst2024DataSet1;
            // 
            // g17Wst2024DataSet1
            // 
            this.g17Wst2024DataSet1.DataSetName = "G17Wst2024DataSet";
            this.g17Wst2024DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pRODUCTTableAdapter
            // 
            this.pRODUCTTableAdapter.ClearBeforeFill = true;
            // 
            // productTableAdapter1
            // 
            this.productTableAdapter1.ClearBeforeFill = true;
            // 
            // pRODUCTcartTableAdapter
            // 
            this.pRODUCTcartTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBoxCollectionMethod);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.comboBoxPaymentMethod);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.btnFinaliseSale);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.comboBoxEmployeeID);
            this.groupBox2.Controls.Add(this.txtCustomerID);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtTotal);
            this.groupBox2.Location = new System.Drawing.Point(43, 79);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(648, 722);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Sale Details";
            // 
            // comboBoxCollectionMethod
            // 
            this.comboBoxCollectionMethod.FormattingEnabled = true;
            this.comboBoxCollectionMethod.Items.AddRange(new object[] {
            "Collection",
            "Delivery"});
            this.comboBoxCollectionMethod.Location = new System.Drawing.Point(168, 361);
            this.comboBoxCollectionMethod.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxCollectionMethod.Name = "comboBoxCollectionMethod";
            this.comboBoxCollectionMethod.Size = new System.Drawing.Size(160, 24);
            this.comboBoxCollectionMethod.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 364);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "Collection Method:";
            // 
            // comboBoxPaymentMethod
            // 
            this.comboBoxPaymentMethod.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.sALEBindingSource, "Payment_Type", true));
            this.comboBoxPaymentMethod.FormattingEnabled = true;
            this.comboBoxPaymentMethod.Items.AddRange(new object[] {
            "card",
            "cash"});
            this.comboBoxPaymentMethod.Location = new System.Drawing.Point(168, 321);
            this.comboBoxPaymentMethod.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxPaymentMethod.Name = "comboBoxPaymentMethod";
            this.comboBoxPaymentMethod.Size = new System.Drawing.Size(160, 24);
            this.comboBoxPaymentMethod.TabIndex = 12;
            // 
            // sALEBindingSource
            // 
            this.sALEBindingSource.DataMember = "SALE";
            this.sALEBindingSource.DataSource = this.g17Wst2024DataSet;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(52, 325);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "Payment Method:";
            // 
            // btnFinaliseSale
            // 
            this.btnFinaliseSale.Location = new System.Drawing.Point(319, 649);
            this.btnFinaliseSale.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFinaliseSale.Name = "btnFinaliseSale";
            this.btnFinaliseSale.Size = new System.Drawing.Size(209, 52);
            this.btnFinaliseSale.TabIndex = 10;
            this.btnFinaliseSale.Text = "Confirm";
            this.btnFinaliseSale.UseVisualStyleBackColor = true;
            this.btnFinaliseSale.Click += new System.EventHandler(this.btnFinaliseSale_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 667);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Total Due:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtCustomerSearch);
            this.groupBox3.Controls.Add(this.dgvCustIDSearch);
            this.groupBox3.Controls.Add(this.btnCustomer);
            this.groupBox3.Location = new System.Drawing.Point(29, 107);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(585, 197);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Select Customer";
            // 
            // txtCustomerSearch
            // 
            this.txtCustomerSearch.Location = new System.Drawing.Point(27, 27);
            this.txtCustomerSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCustomerSearch.Name = "txtCustomerSearch";
            this.txtCustomerSearch.Size = new System.Drawing.Size(132, 23);
            this.txtCustomerSearch.TabIndex = 8;
            this.txtCustomerSearch.TextChanged += new System.EventHandler(this.txtCustomerSearch_TextChanged);
            // 
            // dgvCustIDSearch
            // 
            this.dgvCustIDSearch.AutoGenerateColumns = false;
            this.dgvCustIDSearch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCustIDSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustIDSearch.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customerIDDataGridViewTextBoxColumn,
            this.customerNameDataGridViewTextBoxColumn,
            this.customerSurnameDataGridViewTextBoxColumn});
            this.dgvCustIDSearch.DataSource = this.cUSTOMERBindingSource;
            this.dgvCustIDSearch.Location = new System.Drawing.Point(27, 63);
            this.dgvCustIDSearch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvCustIDSearch.Name = "dgvCustIDSearch";
            this.dgvCustIDSearch.Size = new System.Drawing.Size(529, 122);
            this.dgvCustIDSearch.TabIndex = 7;
            this.dgvCustIDSearch.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCustIDSearch_CellContentClick);
            this.dgvCustIDSearch.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            this.customerIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // customerNameDataGridViewTextBoxColumn
            // 
            this.customerNameDataGridViewTextBoxColumn.DataPropertyName = "Customer_Name";
            this.customerNameDataGridViewTextBoxColumn.HeaderText = "Customer_Name";
            this.customerNameDataGridViewTextBoxColumn.Name = "customerNameDataGridViewTextBoxColumn";
            // 
            // customerSurnameDataGridViewTextBoxColumn
            // 
            this.customerSurnameDataGridViewTextBoxColumn.DataPropertyName = "Customer_Surname";
            this.customerSurnameDataGridViewTextBoxColumn.HeaderText = "Customer_Surname";
            this.customerSurnameDataGridViewTextBoxColumn.Name = "customerSurnameDataGridViewTextBoxColumn";
            // 
            // cUSTOMERBindingSource
            // 
            this.cUSTOMERBindingSource.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource.DataSource = this.g17Wst2024DataSet;
            // 
            // btnCustomer
            // 
            this.btnCustomer.Location = new System.Drawing.Point(405, 27);
            this.btnCustomer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(151, 28);
            this.btnCustomer.TabIndex = 5;
            this.btnCustomer.Text = "Add Customer";
            this.btnCustomer.UseVisualStyleBackColor = true;
            this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
            // 
            // comboBoxEmployeeID
            // 
            this.comboBoxEmployeeID.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.eMPLOYEEBindingSource, "Employee_ID", true));
            this.comboBoxEmployeeID.DataSource = this.eMPLOYEEBindingSource;
            this.comboBoxEmployeeID.DisplayMember = "Employee_ID";
            this.comboBoxEmployeeID.FormattingEnabled = true;
            this.comboBoxEmployeeID.Location = new System.Drawing.Point(123, 36);
            this.comboBoxEmployeeID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxEmployeeID.Name = "comboBoxEmployeeID";
            this.comboBoxEmployeeID.Size = new System.Drawing.Size(160, 24);
            this.comboBoxEmployeeID.TabIndex = 6;
            this.comboBoxEmployeeID.ValueMember = "Employee_ID";
            // 
            // eMPLOYEEBindingSource
            // 
            this.eMPLOYEEBindingSource.DataMember = "EMPLOYEE";
            this.eMPLOYEEBindingSource.DataSource = this.g17Wst2024DataSet;
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.Location = new System.Drawing.Point(123, 68);
            this.txtCustomerID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.Size = new System.Drawing.Size(160, 23);
            this.txtCustomerID.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 71);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Customer ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 39);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Employee ID:";
            // 
            // eMPLOYEETableAdapter
            // 
            this.eMPLOYEETableAdapter.ClearBeforeFill = true;
            // 
            // cUSTOMERTableAdapter
            // 
            this.cUSTOMERTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dgvCart);
            this.groupBox4.Controls.Add(this.btnTotal);
            this.groupBox4.Controls.Add(this.btnCancel);
            this.groupBox4.Location = new System.Drawing.Point(776, 490);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(1071, 311);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Sale Cart";
            // 
            // saleTableAdapter1
            // 
            this.saleTableAdapter1.ClearBeforeFill = true;
            // 
            // salE_ITEMSTableAdapter1
            // 
            this.salE_ITEMSTableAdapter1.ClearBeforeFill = true;
            // 
            // productIDDataGridViewTextBoxColumn1
            // 
            this.productIDDataGridViewTextBoxColumn1.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.Name = "productIDDataGridViewTextBoxColumn1";
            this.productIDDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            // 
            // descriptionDataGridViewTextBoxColumn1
            // 
            this.descriptionDataGridViewTextBoxColumn1.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn1.HeaderText = "description";
            this.descriptionDataGridViewTextBoxColumn1.Name = "descriptionDataGridViewTextBoxColumn1";
            // 
            // salePriceDataGridViewTextBoxColumn1
            // 
            this.salePriceDataGridViewTextBoxColumn1.DataPropertyName = "Sale_Price";
            this.salePriceDataGridViewTextBoxColumn1.HeaderText = "Sale_Price";
            this.salePriceDataGridViewTextBoxColumn1.Name = "salePriceDataGridViewTextBoxColumn1";
            // 
            // Quantity
            // 
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.Quantity.Name = "Quantity";
            this.Quantity.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "available_Stock";
            this.dataGridViewTextBoxColumn1.HeaderText = "available_Stock";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(44, 834);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(188, 62);
            this.btnReturn.TabIndex = 10;
            this.btnReturn.Text = "Return to menu";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // Process_Sale_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1924, 929);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Process_Sale_Form";
            this.Text = "Process Sale";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g17Wst2024DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTcartBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g17Wst2024DataSet1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sALEBindingSource)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustIDSearch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eMPLOYEEBindingSource)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button txtTotal;
        private System.Windows.Forms.DataGridView dgvProductSearch;
        private System.Windows.Forms.DataGridView dgvCart;
        private G17Wst2024DataSet g17Wst2024DataSet;
        private System.Windows.Forms.BindingSource pRODUCTBindingSource;
        private G17Wst2024DataSetTableAdapters.PRODUCTTableAdapter pRODUCTTableAdapter;
        private System.Windows.Forms.TextBox txtProductDescrip;
        private G17Wst2024DataSetTableAdapters.PRODUCTTableAdapter productTableAdapter1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private G17Wst2024DataSet g17Wst2024DataSet1;
        private System.Windows.Forms.BindingSource pRODUCTBindingSource1;
        private System.Windows.Forms.BindingSource pRODUCTcartBindingSource;
        private G17Wst2024DataSetTableAdapters.PRODUCTcartTableAdapter pRODUCTcartTableAdapter;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCustomerID;
        private System.Windows.Forms.Button btnCustomer;
        private System.Windows.Forms.ComboBox comboBoxEmployeeID;
        private System.Windows.Forms.BindingSource eMPLOYEEBindingSource;
        private G17Wst2024DataSetTableAdapters.EMPLOYEETableAdapter eMPLOYEETableAdapter;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvCustIDSearch;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource;
        private G17Wst2024DataSetTableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter;
        private System.Windows.Forms.TextBox txtCustomerSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerSurnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnFinaliseSale;
        private System.Windows.Forms.GroupBox groupBox4;
        private G17Wst2024DataSetTableAdapters.SALETableAdapter saleTableAdapter1;
        private System.Windows.Forms.ComboBox comboBoxCollectionMethod;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxPaymentMethod;
        private System.Windows.Forms.BindingSource sALEBindingSource;
        private System.Windows.Forms.Label label5;
        private G17Wst2024DataSetTableAdapters.SALE_ITEMSTableAdapter salE_ITEMSTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn availableStockDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salePriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn salePriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button btnReturn;
    }
}