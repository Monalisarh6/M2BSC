﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BriteSparx_POS_System
{
    public partial class Process_Sale_Form : Form
    {
        public Process_Sale_Form()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
           
            // TODO: This line of code loads data into the 'g17Wst2024DataSet.EMPLOYEE' table. You can move, or remove it, as needed.
            this.eMPLOYEETableAdapter.Fill(this.g17Wst2024DataSet.EMPLOYEE);
            this.productTableAdapter1.Fill(this.g17Wst2024DataSet.PRODUCT);
            this.cUSTOMERTableAdapter.Fill(this.g17Wst2024DataSet.CUSTOMER);

        }

        private void txtProductDescrip_TextChanged(object sender, EventArgs e)
        {
            productTableAdapter1.FillBy(g17Wst2024DataSet.PRODUCT, txtProductDescrip.Text);
        }

        private decimal getTotal()
        {
            decimal sum = 0;
            for (int i = 0; i < dgvCart.Rows.Count - 1; i++)
            {
                sum += (Convert.ToDecimal(dgvCart.Rows[i].Cells[3].Value)) * (Convert.ToDecimal(dgvCart.Rows[i].Cells[4].Value));
            }
            return sum;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dgvProductSearch_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataRow dr;
            dr = g17Wst2024DataSet.PRODUCTcart.NewRow();
            for (int i = 0; i < dr.ItemArray.Length; i++)
            {
                dr[i] = dgvProductSearch.CurrentRow.Cells[i].Value;
            }
            g17Wst2024DataSet.PRODUCTcart.Rows.Add(dr);
           
            
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvProductSearch_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvCart_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            txtTotal.Text = getTotal().ToString();
        }

        private void dgvCart_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
           
        }

        private void dgvCart_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            txtTotal.Text =getTotal().ToString() ;
        }

        private void btnTotal_Click(object sender, EventArgs e)
        {
            txtTotal.Text = getTotal().ToString();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
           
            g17Wst2024DataSet.Clear();
            txtTotal.Text = "";
            txtProductDescrip.Text = "";
            this.productTableAdapter1.Fill(this.g17Wst2024DataSet.PRODUCT);
            this.cUSTOMERTableAdapter.Fill(this.g17Wst2024DataSet.CUSTOMER);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtProductDescrip.Text = "";
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            Form Edit_Customer_Form = new Edit_Customer_Form();
            Edit_Customer_Form.Show();

        }

        private void txtCustomerSearch_TextChanged(object sender, EventArgs e)
        {
            cUSTOMERTableAdapter.FillBy(g17Wst2024DataSet.CUSTOMER, (string)txtCustomerSearch.Text);
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
           txtCustomerID.Text = dgvCustIDSearch.CurrentRow.Cells[0].Value.ToString();
        }

        private void dgvCustIDSearch_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtTotal_Click(object sender, EventArgs e)
        {

        }

        private void btnFinaliseSale_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Would you like to confirm this sale?", "Sale Confirmation",MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                int SalePK = Convert.ToInt32(Convert.ToDouble(saleTableAdapter1.Count()) + 5);
                saleTableAdapter1.InsertQuery(SalePK,Convert.ToInt32(txtCustomerID.Text), Convert.ToInt32(comboBoxEmployeeID.Text), Convert.ToDecimal(txtTotal.Text), DateTime.Now.ToShortDateString(), DateTime.Now.ToShortTimeString(), comboBoxPaymentMethod.Text, comboBoxCollectionMethod.Text, "In Store", "No");
                saleTableAdapter1.Fill(g17Wst2024DataSet.SALE);
                for (int i = 0; i < dgvCart.Rows.Count - 1; i++)
                {
                    double AvailableQuantity = Convert.ToDouble(dgvCart.Rows[i].Cells[5].Value);
                    double ItemPrice = Convert.ToDouble(dgvCart.Rows[i].Cells[3].Value);
                    double PriceExclVAT = Convert.ToDouble(ItemPrice / 1.15);
                    double qty = Convert.ToDouble(dgvCart.Rows[i].Cells[4].Value);
                    decimal ItemVat = Convert.ToDecimal((ItemPrice - PriceExclVAT) * qty);
                    salE_ITEMSTableAdapter1.InsertSaleItems((int)SalePK,(int) dgvCart.Rows[i].Cells[0].Value, Convert.ToInt32(dgvCart.Rows[i].Cells[4].Value),Convert.ToDecimal(txtTotal.Text), (decimal)ItemVat, "No");
                    productTableAdapter1.UpdateQuant((int)Convert.ToInt32(AvailableQuantity - qty),(int)dgvCart.Rows[i].Cells[0].Value,(int)dgvCart.Rows[i].Cells[0].Value);
                }

            }
            if (result == DialogResult.No)
            {
                MessageBox.Show("Sale not confirmed.");
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Would you like to return to the main menu?", "Confirm return", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
