﻿
namespace BriteSparx_POS_System
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.SaleYearTextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.CRV4 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.EmployeeIDTextBox = new System.Windows.Forms.TextBox();
            this.EmployeeYearTextBox = new System.Windows.Forms.TextBox();
            this.CRV3 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.EmployeeMonthComboBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.GetEmployeeReportButton = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.CRV2 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.ProductNameComboBox = new System.Windows.Forms.ComboBox();
            this.pRODUCTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsReportsForm = new BriteSparx_POS_System.G17Wst2024DataSet();
            this.MonthcomboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.GetProductReportButton = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.CRV1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.YearTextBox = new System.Windows.Forms.TextBox();
            this.CustomerIDTextBox = new System.Windows.Forms.TextBox();
            this.GetCustomerReportButton = new System.Windows.Forms.Button();
            this.taCustomer = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.CUSTOMERTableAdapter();
            this.taSales = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.SALETableAdapter();
            this.crCustomerSales1 = new BriteSparx_POS_System.CrCustomerSales();
            this.pRODUCTTableAdapter = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.PRODUCTTableAdapter();
            this.taSale_Items = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.SALE_ITEMSTableAdapter();
            this.taProduct = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.PRODUCTTableAdapter();
            this.productsByMonth = new BriteSparx_POS_System.ProductsByMonth2();
            this.productsByMonth21 = new BriteSparx_POS_System.ProductsByMonth2();
            this.taEmployee = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.EMPLOYEETableAdapter();
            this.employeeReport21 = new BriteSparx_POS_System.EmployeeReport2();
            this.sales1 = new BriteSparx_POS_System.Sales();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsReportsForm)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(817, 704);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(809, 678);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sales Report";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(803, 672);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.checkBox4);
            this.tabPage5.Controls.Add(this.SaleYearTextBox);
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.button1);
            this.tabPage5.Controls.Add(this.CRV4);
            this.tabPage5.Controls.Add(this.comboBox2);
            this.tabPage5.Controls.Add(this.label10);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(795, 646);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "By Month";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(322, 81);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(114, 17);
            this.checkBox4.TabIndex = 23;
            this.checkBox4.Text = "Enter Custom Year";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // SaleYearTextBox
            // 
            this.SaleYearTextBox.Enabled = false;
            this.SaleYearTextBox.Location = new System.Drawing.Point(165, 81);
            this.SaleYearTextBox.Name = "SaleYearTextBox";
            this.SaleYearTextBox.Size = new System.Drawing.Size(121, 20);
            this.SaleYearTextBox.TabIndex = 22;
            this.SaleYearTextBox.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(78, 91);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "Enter Year";
            this.label11.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(488, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 36);
            this.button1.TabIndex = 20;
            this.button1.Text = "Get Report";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // CRV4
            // 
            this.CRV4.ActiveViewIndex = -1;
            this.CRV4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CRV4.Cursor = System.Windows.Forms.Cursors.Default;
            this.CRV4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.CRV4.Location = new System.Drawing.Point(3, 133);
            this.CRV4.Name = "CRV4";
            this.CRV4.Size = new System.Drawing.Size(789, 510);
            this.CRV4.TabIndex = 19;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(165, 42);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(78, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Select Month";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(809, 678);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Employee Report";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(3, 3);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(803, 672);
            this.tabControl3.TabIndex = 1;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.checkBox3);
            this.tabPage7.Controls.Add(this.EmployeeIDTextBox);
            this.tabPage7.Controls.Add(this.EmployeeYearTextBox);
            this.tabPage7.Controls.Add(this.CRV3);
            this.tabPage7.Controls.Add(this.EmployeeMonthComboBox);
            this.tabPage7.Controls.Add(this.label7);
            this.tabPage7.Controls.Add(this.label8);
            this.tabPage7.Controls.Add(this.label9);
            this.tabPage7.Controls.Add(this.GetEmployeeReportButton);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(795, 646);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "By Month";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(329, 108);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(114, 17);
            this.checkBox3.TabIndex = 19;
            this.checkBox3.Text = "Enter Custom Year";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // EmployeeIDTextBox
            // 
            this.EmployeeIDTextBox.Location = new System.Drawing.Point(190, 6);
            this.EmployeeIDTextBox.Name = "EmployeeIDTextBox";
            this.EmployeeIDTextBox.Size = new System.Drawing.Size(121, 20);
            this.EmployeeIDTextBox.TabIndex = 18;
            // 
            // EmployeeYearTextBox
            // 
            this.EmployeeYearTextBox.Location = new System.Drawing.Point(190, 106);
            this.EmployeeYearTextBox.Name = "EmployeeYearTextBox";
            this.EmployeeYearTextBox.Size = new System.Drawing.Size(121, 20);
            this.EmployeeYearTextBox.TabIndex = 18;
            this.EmployeeYearTextBox.Visible = false;
            // 
            // CRV3
            // 
            this.CRV3.ActiveViewIndex = -1;
            this.CRV3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CRV3.Cursor = System.Windows.Forms.Cursors.Default;
            this.CRV3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.CRV3.Location = new System.Drawing.Point(3, 133);
            this.CRV3.Name = "CRV3";
            this.CRV3.Size = new System.Drawing.Size(789, 510);
            this.CRV3.TabIndex = 17;
            // 
            // EmployeeMonthComboBox
            // 
            this.EmployeeMonthComboBox.FormattingEnabled = true;
            this.EmployeeMonthComboBox.Location = new System.Drawing.Point(190, 51);
            this.EmployeeMonthComboBox.Name = "EmployeeMonthComboBox";
            this.EmployeeMonthComboBox.Size = new System.Drawing.Size(121, 21);
            this.EmployeeMonthComboBox.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(81, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Enter Year";
            this.label7.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(81, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Select Month";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(81, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Enter Employee ID";
            // 
            // GetEmployeeReportButton
            // 
            this.GetEmployeeReportButton.Location = new System.Drawing.Point(578, 51);
            this.GetEmployeeReportButton.Name = "GetEmployeeReportButton";
            this.GetEmployeeReportButton.Size = new System.Drawing.Size(119, 36);
            this.GetEmployeeReportButton.TabIndex = 11;
            this.GetEmployeeReportButton.Text = "Get Report";
            this.GetEmployeeReportButton.UseVisualStyleBackColor = true;
            this.GetEmployeeReportButton.Click += new System.EventHandler(this.GetEmployeeReportButton_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl4);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(809, 678);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Product Report";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage9);
            this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl4.Location = new System.Drawing.Point(3, 3);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(803, 672);
            this.tabControl4.TabIndex = 1;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.checkBox2);
            this.tabPage9.Controls.Add(this.textBox1);
            this.tabPage9.Controls.Add(this.CRV2);
            this.tabPage9.Controls.Add(this.ProductNameComboBox);
            this.tabPage9.Controls.Add(this.MonthcomboBox);
            this.tabPage9.Controls.Add(this.label6);
            this.tabPage9.Controls.Add(this.label5);
            this.tabPage9.Controls.Add(this.label2);
            this.tabPage9.Controls.Add(this.GetProductReportButton);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(795, 646);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "By Month";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(340, 107);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(114, 17);
            this.checkBox2.TabIndex = 11;
            this.checkBox2.Text = "Enter Custom Year";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(190, 107);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 20);
            this.textBox1.TabIndex = 10;
            this.textBox1.Visible = false;
            // 
            // CRV2
            // 
            this.CRV2.ActiveViewIndex = -1;
            this.CRV2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CRV2.Cursor = System.Windows.Forms.Cursors.Default;
            this.CRV2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.CRV2.Location = new System.Drawing.Point(3, 133);
            this.CRV2.Name = "CRV2";
            this.CRV2.Size = new System.Drawing.Size(789, 510);
            this.CRV2.TabIndex = 9;
            // 
            // ProductNameComboBox
            // 
            this.ProductNameComboBox.DataSource = this.pRODUCTBindingSource;
            this.ProductNameComboBox.DisplayMember = "name";
            this.ProductNameComboBox.FormattingEnabled = true;
            this.ProductNameComboBox.Location = new System.Drawing.Point(190, 6);
            this.ProductNameComboBox.Name = "ProductNameComboBox";
            this.ProductNameComboBox.Size = new System.Drawing.Size(121, 21);
            this.ProductNameComboBox.TabIndex = 8;
            this.ProductNameComboBox.ValueMember = "name";
            // 
            // pRODUCTBindingSource
            // 
            this.pRODUCTBindingSource.DataMember = "PRODUCT";
            this.pRODUCTBindingSource.DataSource = this.dsReportsForm;
            // 
            // dsReportsForm
            // 
            this.dsReportsForm.DataSetName = "G17Wst2024DataSet";
            this.dsReportsForm.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // MonthcomboBox
            // 
            this.MonthcomboBox.FormattingEnabled = true;
            this.MonthcomboBox.Location = new System.Drawing.Point(190, 52);
            this.MonthcomboBox.Name = "MonthcomboBox";
            this.MonthcomboBox.Size = new System.Drawing.Size(121, 21);
            this.MonthcomboBox.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(81, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Enter Year";
            this.label6.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(81, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Select Month";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(81, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Select Product Name";
            // 
            // GetProductReportButton
            // 
            this.GetProductReportButton.Location = new System.Drawing.Point(578, 52);
            this.GetProductReportButton.Name = "GetProductReportButton";
            this.GetProductReportButton.Size = new System.Drawing.Size(119, 36);
            this.GetProductReportButton.TabIndex = 5;
            this.GetProductReportButton.Text = "Get Report";
            this.GetProductReportButton.UseVisualStyleBackColor = true;
            this.GetProductReportButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.tabControl5);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(809, 678);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Customer Report";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage11);
            this.tabControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl5.Location = new System.Drawing.Point(3, 3);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(803, 672);
            this.tabControl5.TabIndex = 1;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.checkBox1);
            this.tabPage11.Controls.Add(this.comboBox1);
            this.tabPage11.Controls.Add(this.CRV1);
            this.tabPage11.Controls.Add(this.label4);
            this.tabPage11.Controls.Add(this.label3);
            this.tabPage11.Controls.Add(this.label1);
            this.tabPage11.Controls.Add(this.YearTextBox);
            this.tabPage11.Controls.Add(this.CustomerIDTextBox);
            this.tabPage11.Controls.Add(this.GetCustomerReportButton);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(795, 646);
            this.tabPage11.TabIndex = 0;
            this.tabPage11.Text = "By Month";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(286, 99);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(114, 17);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "Enter Custom Year";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(170, 57);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 4;
            // 
            // CRV1
            // 
            this.CRV1.ActiveViewIndex = -1;
            this.CRV1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CRV1.Cursor = System.Windows.Forms.Cursors.Default;
            this.CRV1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.CRV1.Location = new System.Drawing.Point(3, 125);
            this.CRV1.MinimumSize = new System.Drawing.Size(500, 500);
            this.CRV1.Name = "CRV1";
            this.CRV1.Size = new System.Drawing.Size(789, 518);
            this.CRV1.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(71, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Enter Year";
            this.label4.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Select Month";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter Customer ID";
            // 
            // YearTextBox
            // 
            this.YearTextBox.Enabled = false;
            this.YearTextBox.Location = new System.Drawing.Point(170, 99);
            this.YearTextBox.Name = "YearTextBox";
            this.YearTextBox.Size = new System.Drawing.Size(100, 20);
            this.YearTextBox.TabIndex = 1;
            this.YearTextBox.Visible = false;
            // 
            // CustomerIDTextBox
            // 
            this.CustomerIDTextBox.Location = new System.Drawing.Point(170, 13);
            this.CustomerIDTextBox.Name = "CustomerIDTextBox";
            this.CustomerIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.CustomerIDTextBox.TabIndex = 1;
            // 
            // GetCustomerReportButton
            // 
            this.GetCustomerReportButton.Location = new System.Drawing.Point(559, 48);
            this.GetCustomerReportButton.Name = "GetCustomerReportButton";
            this.GetCustomerReportButton.Size = new System.Drawing.Size(119, 36);
            this.GetCustomerReportButton.TabIndex = 0;
            this.GetCustomerReportButton.Text = "Get Report";
            this.GetCustomerReportButton.UseVisualStyleBackColor = true;
            this.GetCustomerReportButton.Click += new System.EventHandler(this.GetReportButton_Click);
            // 
            // taCustomer
            // 
            this.taCustomer.ClearBeforeFill = true;
            // 
            // taSales
            // 
            this.taSales.ClearBeforeFill = true;
            // 
            // pRODUCTTableAdapter
            // 
            this.pRODUCTTableAdapter.ClearBeforeFill = true;
            // 
            // taSale_Items
            // 
            this.taSale_Items.ClearBeforeFill = true;
            // 
            // taProduct
            // 
            this.taProduct.ClearBeforeFill = true;
            // 
            // taEmployee
            // 
            this.taEmployee.ClearBeforeFill = true;
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(817, 704);
            this.Controls.Add(this.tabControl1);
            this.Name = "Reports";
            this.Text = "Reports";
            this.Load += new System.EventHandler(this.Reports_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pRODUCTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsReportsForm)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage11;
        private G17Wst2024DataSet dsReportsForm;
        private G17Wst2024DataSetTableAdapters.CUSTOMERTableAdapter taCustomer;
        private G17Wst2024DataSetTableAdapters.SALETableAdapter taSales;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CustomerIDTextBox;
        private System.Windows.Forms.Button GetCustomerReportButton;
        private CrCustomerSales crCustomerSales1;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer CRV1;
        private System.Windows.Forms.ComboBox MonthcomboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button GetProductReportButton;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer CRV2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox YearTextBox;
        private System.Windows.Forms.ComboBox ProductNameComboBox;
        private System.Windows.Forms.BindingSource pRODUCTBindingSource;
        private G17Wst2024DataSetTableAdapters.PRODUCTTableAdapter pRODUCTTableAdapter;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private G17Wst2024DataSetTableAdapters.SALE_ITEMSTableAdapter taSale_Items;
        private G17Wst2024DataSetTableAdapters.PRODUCTTableAdapter taProduct;
        private ProductsByMonth2 productsByMonth;
        private ProductsByMonth2 productsByMonth21;
        private G17Wst2024DataSetTableAdapters.EMPLOYEETableAdapter taEmployee;
        private System.Windows.Forms.TextBox EmployeeIDTextBox;
        private System.Windows.Forms.TextBox EmployeeYearTextBox;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer CRV3;
        private System.Windows.Forms.ComboBox EmployeeMonthComboBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button GetEmployeeReportButton;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private EmployeeReport2 employeeReport21;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer CRV4;
        private Sales sales1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.TextBox SaleYearTextBox;
        private System.Windows.Forms.Label label11;
    }
}