﻿
namespace BriteSparx_POS_System
{
    partial class Edit_Customer_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCustomerEmail = new System.Windows.Forms.TextBox();
            this.txtCustomerPassword = new System.Windows.Forms.TextBox();
            this.txtEmployeeCellphoneNumber = new System.Windows.Forms.TextBox();
            this.txtCustomerSurname = new System.Windows.Forms.TextBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.txtCustTown = new System.Windows.Forms.TextBox();
            this.txtCustomerSuburb = new System.Windows.Forms.TextBox();
            this.txtCustomerStreetname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.comboBoxArchiveStatus = new System.Windows.Forms.ComboBox();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnUpdateCustomer = new System.Windows.Forms.Button();
            this.dgvCustomer = new System.Windows.Forms.DataGridView();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer_Surname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer_Cellphone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer_Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer_Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Street_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Suburb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Town = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Postal_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Archive_Status = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.cUSTOMERBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.g17Wst2024DataSet = new BriteSparx_POS_System.G17Wst2024DataSet();
            this.fKSALECUSTOMER1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cUSTOMERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtCustomerSearch = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cUSTOMERTableAdapter = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.CUSTOMERTableAdapter();
            this.cUSTOMERBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cUSTOMERBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.g17Wst2024DataSet1 = new BriteSparx_POS_System.G17Wst2024DataSet();
            this.sALETableAdapter = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.SALETableAdapter();
            this.customerTableAdapter1 = new BriteSparx_POS_System.G17Wst2024DataSetTableAdapters.CUSTOMERTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g17Wst2024DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKSALECUSTOMER1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g17Wst2024DataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(116, 47);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerName.TabIndex = 0;
            this.txtCustomerName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(25, 54);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(85, 13);
            this.label45.TabIndex = 1;
            this.label45.Text = "Customer Name:";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(239, 54);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(99, 13);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Customer Surname:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 96);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Cellphone No. :";
            // 
            // txtCustomerEmail
            // 
            this.txtCustomerEmail.Location = new System.Drawing.Point(344, 89);
            this.txtCustomerEmail.Name = "txtCustomerEmail";
            this.txtCustomerEmail.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerEmail.TabIndex = 5;
            // 
            // txtCustomerPassword
            // 
            this.txtCustomerPassword.Location = new System.Drawing.Point(551, 51);
            this.txtCustomerPassword.Name = "txtCustomerPassword";
            this.txtCustomerPassword.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerPassword.TabIndex = 6;
            // 
            // txtEmployeeCellphoneNumber
            // 
            this.txtEmployeeCellphoneNumber.Location = new System.Drawing.Point(116, 89);
            this.txtEmployeeCellphoneNumber.Name = "txtEmployeeCellphoneNumber";
            this.txtEmployeeCellphoneNumber.Size = new System.Drawing.Size(100, 20);
            this.txtEmployeeCellphoneNumber.TabIndex = 7;
            // 
            // txtCustomerSurname
            // 
            this.txtCustomerSurname.Location = new System.Drawing.Point(344, 51);
            this.txtCustomerSurname.Name = "txtCustomerSurname";
            this.txtCustomerSurname.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerSurname.TabIndex = 8;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(262, 92);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(76, 13);
            this.Label12.TabIndex = 4;
            this.Label12.Text = "Email Address:";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(489, 54);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(56, 13);
            this.lbl3.TabIndex = 9;
            this.lbl3.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(726, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Town:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(719, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Suburb:";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(476, 96);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(69, 13);
            this.lbl4.TabIndex = 12;
            this.lbl4.Text = "Street Name:";
            // 
            // txtCustTown
            // 
            this.txtCustTown.Location = new System.Drawing.Point(769, 89);
            this.txtCustTown.Name = "txtCustTown";
            this.txtCustTown.Size = new System.Drawing.Size(100, 20);
            this.txtCustTown.TabIndex = 13;
            this.txtCustTown.TextChanged += new System.EventHandler(this.txtCustTown_TextChanged);
            // 
            // txtCustomerSuburb
            // 
            this.txtCustomerSuburb.Location = new System.Drawing.Point(769, 51);
            this.txtCustomerSuburb.Name = "txtCustomerSuburb";
            this.txtCustomerSuburb.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerSuburb.TabIndex = 14;
            // 
            // txtCustomerStreetname
            // 
            this.txtCustomerStreetname.Location = new System.Drawing.Point(551, 93);
            this.txtCustomerStreetname.Name = "txtCustomerStreetname";
            this.txtCustomerStreetname.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerStreetname.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(928, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Archive:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(910, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Postal Code";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(980, 51);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(100, 20);
            this.txtPostalCode.TabIndex = 19;
            this.txtPostalCode.TextChanged += new System.EventHandler(this.txtPostalCode_TextChanged);
            // 
            // comboBoxArchiveStatus
            // 
            this.comboBoxArchiveStatus.FormattingEnabled = true;
            this.comboBoxArchiveStatus.Items.AddRange(new object[] {
            "True",
            "False"});
            this.comboBoxArchiveStatus.Location = new System.Drawing.Point(980, 89);
            this.comboBoxArchiveStatus.Name = "comboBoxArchiveStatus";
            this.comboBoxArchiveStatus.Size = new System.Drawing.Size(121, 21);
            this.comboBoxArchiveStatus.TabIndex = 20;
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.Location = new System.Drawing.Point(28, 124);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(110, 41);
            this.btnAddCustomer.TabIndex = 21;
            this.btnAddCustomer.Text = "Add New Customer";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.btnAddCustomer_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(187, 463);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 41);
            this.button3.TabIndex = 23;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // btnUpdateCustomer
            // 
            this.btnUpdateCustomer.Location = new System.Drawing.Point(43, 463);
            this.btnUpdateCustomer.Name = "btnUpdateCustomer";
            this.btnUpdateCustomer.Size = new System.Drawing.Size(110, 41);
            this.btnUpdateCustomer.TabIndex = 24;
            this.btnUpdateCustomer.Text = "Update";
            this.btnUpdateCustomer.UseVisualStyleBackColor = true;
            this.btnUpdateCustomer.Click += new System.EventHandler(this.btnUpdateCustomer_Click);
            // 
            // dgvCustomer
            // 
            this.dgvCustomer.AutoGenerateColumns = false;
            this.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customerIDDataGridViewTextBoxColumn,
            this.Customer_Name,
            this.Customer_Surname,
            this.Customer_Cellphone,
            this.Customer_Email,
            this.Customer_Password,
            this.Street_Name,
            this.Suburb,
            this.Town,
            this.Postal_Code,
            this.Archive_Status});
            this.dgvCustomer.DataSource = this.cUSTOMERBindingSource3;
            this.dgvCustomer.Location = new System.Drawing.Point(15, 288);
            this.dgvCustomer.Name = "dgvCustomer";
            this.dgvCustomer.Size = new System.Drawing.Size(1144, 150);
            this.dgvCustomer.TabIndex = 25;
            this.dgvCustomer.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCustomer_CellContentClick);
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            this.customerIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Customer_Name
            // 
            this.Customer_Name.DataPropertyName = "Customer_Name";
            this.Customer_Name.HeaderText = "Customer_Name";
            this.Customer_Name.Name = "Customer_Name";
            // 
            // Customer_Surname
            // 
            this.Customer_Surname.DataPropertyName = "Customer_Surname";
            this.Customer_Surname.HeaderText = "Customer_Surname";
            this.Customer_Surname.Name = "Customer_Surname";
            // 
            // Customer_Cellphone
            // 
            this.Customer_Cellphone.DataPropertyName = "Customer_Cellphone";
            this.Customer_Cellphone.HeaderText = "Customer_Cellphone";
            this.Customer_Cellphone.Name = "Customer_Cellphone";
            // 
            // Customer_Email
            // 
            this.Customer_Email.DataPropertyName = "Customer_Email";
            this.Customer_Email.HeaderText = "Customer_Email";
            this.Customer_Email.Name = "Customer_Email";
            // 
            // Customer_Password
            // 
            this.Customer_Password.DataPropertyName = "Customer_Password";
            this.Customer_Password.HeaderText = "Customer_Password";
            this.Customer_Password.Name = "Customer_Password";
            // 
            // Street_Name
            // 
            this.Street_Name.DataPropertyName = "Street_Name";
            this.Street_Name.HeaderText = "Street_Name";
            this.Street_Name.Name = "Street_Name";
            // 
            // Suburb
            // 
            this.Suburb.DataPropertyName = "Suburb";
            this.Suburb.HeaderText = "Suburb";
            this.Suburb.Name = "Suburb";
            // 
            // Town
            // 
            this.Town.DataPropertyName = "Town";
            this.Town.HeaderText = "Town";
            this.Town.Name = "Town";
            // 
            // Postal_Code
            // 
            this.Postal_Code.DataPropertyName = "Postal_Code";
            this.Postal_Code.HeaderText = "Postal_Code";
            this.Postal_Code.Name = "Postal_Code";
            // 
            // Archive_Status
            // 
            this.Archive_Status.DataPropertyName = "Archive_Status";
            this.Archive_Status.HeaderText = "Archive_Status";
            this.Archive_Status.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.Archive_Status.Name = "Archive_Status";
            this.Archive_Status.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Archive_Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // cUSTOMERBindingSource3
            // 
            this.cUSTOMERBindingSource3.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource3.DataSource = this.g17Wst2024DataSet;
            // 
            // g17Wst2024DataSet
            // 
            this.g17Wst2024DataSet.DataSetName = "G17Wst2024DataSet";
            this.g17Wst2024DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fKSALECUSTOMER1BindingSource
            // 
            this.fKSALECUSTOMER1BindingSource.DataMember = "FK_SALE_CUSTOMER1";
            this.fKSALECUSTOMER1BindingSource.DataSource = this.cUSTOMERBindingSource;
            // 
            // cUSTOMERBindingSource
            // 
            this.cUSTOMERBindingSource.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource.DataSource = this.g17Wst2024DataSet;
            // 
            // txtCustomerSearch
            // 
            this.txtCustomerSearch.Location = new System.Drawing.Point(172, 247);
            this.txtCustomerSearch.Name = "txtCustomerSearch";
            this.txtCustomerSearch.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerSearch.TabIndex = 26;
            this.txtCustomerSearch.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCustomerPassword);
            this.groupBox1.Controls.Add(this.txtCustomerName);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.lbl2);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.Label12);
            this.groupBox1.Controls.Add(this.btnAddCustomer);
            this.groupBox1.Controls.Add(this.txtCustomerEmail);
            this.groupBox1.Controls.Add(this.comboBoxArchiveStatus);
            this.groupBox1.Controls.Add(this.txtEmployeeCellphoneNumber);
            this.groupBox1.Controls.Add(this.txtPostalCode);
            this.groupBox1.Controls.Add(this.txtCustomerSurname);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lbl3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtCustomerStreetname);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtCustomerSuburb);
            this.groupBox1.Controls.Add(this.lbl4);
            this.groupBox1.Controls.Add(this.txtCustTown);
            this.groupBox1.Location = new System.Drawing.Point(15, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1157, 171);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "New Customer Details";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 250);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "Search Customer Profile:";
            // 
            // cUSTOMERTableAdapter
            // 
            this.cUSTOMERTableAdapter.ClearBeforeFill = true;
            // 
            // cUSTOMERBindingSource1
            // 
            this.cUSTOMERBindingSource1.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource1.DataSource = this.g17Wst2024DataSet;
            // 
            // cUSTOMERBindingSource2
            // 
            this.cUSTOMERBindingSource2.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource2.DataSource = this.g17Wst2024DataSet1;
            // 
            // g17Wst2024DataSet1
            // 
            this.g17Wst2024DataSet1.DataSetName = "G17Wst2024DataSet";
            this.g17Wst2024DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sALETableAdapter
            // 
            this.sALETableAdapter.ClearBeforeFill = true;
            // 
            // customerTableAdapter1
            // 
            this.customerTableAdapter1.ClearBeforeFill = true;
            // 
            // Edit_Customer_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 551);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtCustomerSearch);
            this.Controls.Add(this.dgvCustomer);
            this.Controls.Add(this.btnUpdateCustomer);
            this.Controls.Add(this.button3);
            this.Name = "Edit_Customer_Form";
            this.Text = "Edit Customer:";
            this.Load += new System.EventHandler(this.Edit_Customer_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g17Wst2024DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKSALECUSTOMER1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g17Wst2024DataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCustomerEmail;
        private System.Windows.Forms.TextBox txtCustomerPassword;
        private System.Windows.Forms.TextBox txtEmployeeCellphoneNumber;
        private System.Windows.Forms.TextBox txtCustomerSurname;
        private System.Windows.Forms.Label Label12;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.TextBox txtCustTown;
        private System.Windows.Forms.TextBox txtCustomerSuburb;
        private System.Windows.Forms.TextBox txtCustomerStreetname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.ComboBox comboBoxArchiveStatus;
        private G17Wst2024DataSet g17Wst2024DataSet;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource;
        private G17Wst2024DataSetTableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource1;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnUpdateCustomer;
        private System.Windows.Forms.DataGridView dgvCustomer;
        private System.Windows.Forms.BindingSource fKSALECUSTOMER1BindingSource;
        private G17Wst2024DataSetTableAdapters.SALETableAdapter sALETableAdapter;
        private G17Wst2024DataSet g17Wst2024DataSet1;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource2;
        private System.Windows.Forms.TextBox txtCustomerSearch;
        private G17Wst2024DataSetTableAdapters.CUSTOMERTableAdapter customerTableAdapter1;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer_Surname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer_Cellphone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer_Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer_Password;
        private System.Windows.Forms.DataGridViewTextBoxColumn Street_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Suburb;
        private System.Windows.Forms.DataGridViewTextBoxColumn Town;
        private System.Windows.Forms.DataGridViewTextBoxColumn Postal_Code;
        private System.Windows.Forms.DataGridViewComboBoxColumn Archive_Status;
    }
}