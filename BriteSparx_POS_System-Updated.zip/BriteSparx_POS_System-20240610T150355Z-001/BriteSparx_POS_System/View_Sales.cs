﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BriteSparx_POS_System
{
    public partial class View_Sales : Form
    {
        public View_Sales()
        {
            InitializeComponent();
        }

        private void View_Sales_Load(object sender, EventArgs e)
        {
            
            
            // TODO: This line of code loads data into the 'g17Wst2024DataSet.SALE' table. You can move, or remove it, as needed.
            this.sALETableAdapter.Fill(this.g17Wst2024DataSet.SALE);

        }

        private void dgvSales_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dgvSales_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            sALE_ITEMSTableAdapter.FillBySaleID(g17Wst2024DataSet.SALE_ITEMS, Convert.ToInt32(dgvSales.CurrentRow.Cells[0].Value));
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Would you like to return to the main menu?", "Confirm return", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
