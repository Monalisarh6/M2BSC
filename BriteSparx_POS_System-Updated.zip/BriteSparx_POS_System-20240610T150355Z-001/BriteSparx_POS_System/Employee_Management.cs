﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BriteSparx_POS_System
{
    public partial class Employee_Management : Form
    {
        public Employee_Management()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            taEmployee.Fill(g17Wst2024DataSet.EMPLOYEE);

            
        }

        private void txtEmployeeSearch_TextChanged(object sender, EventArgs e)
        {
            taEmployee.FillBy(g17Wst2024DataSet.EMPLOYEE, txtEmployeeSearch.Text);
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddNewEmployee_Click(object sender, EventArgs e)
        {
            try
            {
                taEmployee.InsertQuery((string)txtNewEmployeeName.Text, (string)txtNewEmployeeSurname.Text, (string)txtNewEmployeeCell.Text, (string)txtNewEmployeeEmail.Text, (string)txtNewEmployeePassword.Text, (decimal)Convert.ToDecimal(txtNewEmployeeSalary.Text), (string)txtNewEmployeePosition.Text, (string)txtNewEmployeeIDno.Text, (string)("No"));  
                MessageBox.Show("New Employee Profile successfully added.");
            }
            catch
            {
                MessageBox.Show("New Employee Profile has FAILED to be added.");
            }
        }

        private void btnUpdateEmployeeInfo_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Would you like to update this profile ?","Update Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
                {
                taEmployee.UpdateQuery((string)txtNewEmployeeName.Text, (string)txtNewEmployeeSurname.Text, (string)txtNewEmployeeCell.Text, (string)txtNewEmployeeEmail.Text, (string)txtNewEmployeePassword.Text, (decimal)Convert.ToDecimal(txtNewEmployeeSalary.Text), (string)txtNewEmployeePosition.Text, (string)txtNewEmployeeIDno.Text, (string)cbArchiveStatus.Text, (int)dgvEmployeeManagement.CurrentRow.Cells[0].Value, (string)dgvEmployeeManagement.CurrentRow.Cells[1].Value);
                taEmployee.Fill(g17Wst2024DataSet.EMPLOYEE);
                MessageBox.Show("Details successfully updated.");
                }
            else if (result == DialogResult.No)
            {
                MessageBox.Show("Update Cancelled.");
            }
        }

        private void dgvEmployeeManagement_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvEmployeeManagement_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtNewEmployeeName.Text = dgvEmployeeManagement.CurrentRow.Cells[1].Value.ToString();
            txtNewEmployeeSurname.Text = dgvEmployeeManagement.CurrentRow.Cells[2].Value.ToString();
            txtNewEmployeeCell.Text = dgvEmployeeManagement.CurrentRow.Cells[3].Value.ToString();
            txtNewEmployeeEmail.Text = dgvEmployeeManagement.CurrentRow.Cells[4].Value.ToString();
            txtNewEmployeePassword.Text = dgvEmployeeManagement.CurrentRow.Cells[5].Value.ToString();
            txtNewEmployeeSalary.Text = dgvEmployeeManagement.CurrentRow.Cells[6].Value.ToString();
            txtNewEmployeePosition.Text = dgvEmployeeManagement.CurrentRow.Cells[7].Value.ToString();
            txtNewEmployeeIDno.Text = dgvEmployeeManagement.CurrentRow.Cells[8].Value.ToString();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Would you like to return to the main menu?", "Confirm return", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNewEmployeeName.Text = " ";
            txtNewEmployeeSurname.Text = " ";
            txtNewEmployeeCell.Text = " ";
            txtNewEmployeeEmail.Text = " ";
            txtNewEmployeePassword.Text = " ";
            txtNewEmployeeSalary.Text = " ";
            txtNewEmployeePosition.Text = " ";
            txtNewEmployeeIDno.Text = " ";
        }
    }
}
