﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BriteSparx_POS_System
{
    public partial class Inventory_Management : Form
    {
        public Inventory_Management()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            pRODUCTTableAdapter.Fill(g17Wst2024DataSet.PRODUCT);

        }

        private void txtsearchProduct_TextChanged(object sender, EventArgs e)
        {
            pRODUCTTableAdapter.FillBy(g17Wst2024DataSet.PRODUCT, txtsearchProduct.Text);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                pRODUCTTableAdapter.InsertQuery((string)txtNewProdName.Text, (string)txtNewProdDescription.Text, (int)Convert.ToInt32(txtNewProdAvailStock.Text), (decimal)Convert.ToDecimal(txtNewProdSalePrice.Text), (int)Convert.ToInt32(txtNewProdReoder.Text), (string)txtNewProdArchiveStat.Text);
                MessageBox.Show("New Product added successfully");
                pRODUCTTableAdapter.Fill(g17Wst2024DataSet.PRODUCT);
            }
            catch
            {
                MessageBox.Show("New Product failed to be added.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Would you like to return to the main menu?", "Confirm return", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                pRODUCTTableAdapter.UpdateQuery((string)txtNewProdName.Text, (string)txtNewProdDescription.Text, (int)Convert.ToInt32(txtNewProdAvailStock.Text), (decimal)Convert.ToDecimal(txtNewProdSalePrice.Text), (int)Convert.ToInt32(txtNewProdReoder.Text), (string)txtNewProdArchiveStat.Text, (int)dgvProductManage.CurrentRow.Cells[0].Value, (string)dgvProductManage.CurrentRow.Cells[1].Value);
                MessageBox.Show("Product Successfully Updated.");
            }
            else
            {
                MessageBox.Show("Product update has failed.");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Would you like to return to the main menu?", "Confirm return", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void dgvProductManage_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvProductManage_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtNewProdName.Text = dgvProductManage.CurrentRow.Cells[1].Value.ToString();
            txtNewProdDescription.Text = dgvProductManage.CurrentRow.Cells[2].Value.ToString();
            txtNewProdAvailStock.Text = dgvProductManage.CurrentRow.Cells[3].Value.ToString();
            txtNewProdSalePrice.Text = dgvProductManage.CurrentRow.Cells[4].Value.ToString();
            txtNewProdReoder.Text = dgvProductManage.CurrentRow.Cells[5].Value.ToString();
            txtNewProdArchiveStat.Text = dgvProductManage.CurrentRow.Cells[6].Value.ToString();
        }
    }
}
