﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BriteSparx_POS_System
{
    public partial class Edit_Customer_Form : Form
    {
        public Edit_Customer_Form()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Edit_Customer_Form_Load(object sender, EventArgs e)
        {
           
            // TODO: This line of code loads data into the 'g17Wst2024DataSet.SALE' table. You can move, or remove it, as needed.
            this.sALETableAdapter.Fill(this.g17Wst2024DataSet.SALE);
          

        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                cUSTOMERTableAdapter.InsertQuery(txtCustomerName.Text, txtCustomerSurname.Text, txtEmployeeCellphoneNumber.Text, txtCustomerEmail.Text, txtCustomerPassword.Text, txtCustomerStreetname.Text, txtCustomerSuburb.Text, txtCustTown.Text, txtPostalCode.Text, comboBoxArchiveStatus.Text);
                MessageBox.Show("Customer Added Successfully");

            }
            catch
            {
                MessageBox.Show("Failed to add new customer");
            }
        }

        private void txtCustTown_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPostalCode_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            customerTableAdapter1.FillBy(g17Wst2024DataSet.CUSTOMER, txtCustomerSearch.Text);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnUpdateCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                customerTableAdapter1.UpdateQuery((string)dgvCustomer.CurrentRow.Cells[1].Value, (string)dgvCustomer.CurrentRow.Cells[2].Value, (string)dgvCustomer.CurrentRow.Cells[3].Value, (string)dgvCustomer.CurrentRow.Cells[4].Value, (string)dgvCustomer.CurrentRow.Cells[5].Value, (string)dgvCustomer.CurrentRow.Cells[6].Value, (string)dgvCustomer.CurrentRow.Cells[7].Value, (string)dgvCustomer.CurrentRow.Cells[8].Value, (string)dgvCustomer.CurrentRow.Cells[9].Value, (string)dgvCustomer.CurrentRow.Cells[10].Value, (int)dgvCustomer.CurrentRow.Cells[0].Value, (int)dgvCustomer.CurrentRow.Cells[0].Value);
                MessageBox.Show("Successfully Updated Customer Profile");
            }
            catch
            {
                MessageBox.Show("Failed to update customer profile");
            }
        }

        private void dgvCustomer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
