﻿namespace BriteSparx_POS_System
{
}

namespace BriteSparx_POS_System
{
}

namespace BriteSparx_POS_System
{
}

namespace BriteSparx_POS_System
{
}

namespace BriteSparx_POS_System
{
}
namespace BriteSparx_POS_System
{


    public partial class G17Wst2024DataSet
    {
    }
}
namespace BriteSparx_POS_System {
    
    
    public partial class G17Wst2024DataSet {
    }
}

namespace BriteSparx_POS_System.G17Wst2024DataSetTableAdapters {
    
    
    public partial class PRODUCTcartTableAdapter {
    }
}
